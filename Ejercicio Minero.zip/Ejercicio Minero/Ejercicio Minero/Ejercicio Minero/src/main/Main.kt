import kotlin.random.Random

fun main() {

   val random = Random

   val bobObject = bob(random.nextInt(3),0,random.nextInt(5))

   val minaObject = mina()


   bobObject.show()

   for(num in 1..20) {


      if (bobObject.GoldPocket < 3) {
         bobObject.GoldPocket = (minaObject.GoldPocketFun(bobObject.GoldPocket))
         bobObject.Thirst = (minaObject.ThristyFun(bobObject.Thirst))
         bobObject.Fatigue = (minaObject.FatigueFun(bobObject.Fatigue))
         println("Bob: Recolectando una pepita de oro, oro actual : ${bobObject.GoldPocket}")
         Thread.sleep(1000)
      } else {
         println("Minero Bob: Voy para el banco, si señor")
         Thread.sleep(1000)
         bobObject.GoldPocket = (minaObject.GoldPocketFun(bobObject.GoldPocket))
         println("Minero Bob: Depositando el oro en el banco. Total de oro ahorrado: ${minaObject.total} ")
         Thread.sleep(1000)



         if (bobObject.Fatigue >= 8) {
            bobObject.Fatigue = (minaObject.FatigueFunBank(bobObject.Fatigue))
            println("Minero Bob: Me siento muy cansado. Iré a descansar.")
            Thread.sleep(1000)
            println("Minero Bob: De camino a mi hogar dulce hogar.")
            Thread.sleep(1000)
            println("Minero Bob: Hogar dulce hogar.")
            Thread.sleep(1000)
            println("Minero Bob: Zzzzz...")
            Thread.sleep(1000)
            println("Minero Bob: De regreso a la mina.")
            Thread.sleep(1000)
         }

      }

      // Si bob se pone sediento
      if (bobObject.Thirst >= 5) {
         println("Minero Bob: Hombre, estoy sediento. Me dirijo a la taberna.")
         Thread.sleep(1000)
         bobObject.Thirst = (minaObject.ThristyFun(bobObject.Thirst))
      }


}

