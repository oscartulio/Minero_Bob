class hogar{

    fun Home(Fat : Int): Int
    {
        return Fat - Fat
    }
}