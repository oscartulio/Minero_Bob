class taverna{

    fun tavern(sed : Int): Int{
        return sed - 5
    }
}