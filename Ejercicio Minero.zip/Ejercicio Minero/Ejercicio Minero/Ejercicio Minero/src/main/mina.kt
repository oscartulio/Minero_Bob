
open class minaClass
{
    val hogar = hogarClass()
    val banco = bancoClass()
    val taverna = tavernaClass()


    open fun bolsa(OroBolsa: Int): Int
    {
        // var totalOro: Int
        if(OroBolsa < 3) {
            val Oro = OroBolsa
            return Oro + 1
        }else{
            //Here Bob Must Go to the Bank
            total = banco.bolsaBanco(OroBolsa)
            return OroBolsa - OroBolsa
        }
    }

    open fun SedientoFun(Sed : Int): Int
    {
        if (Sed < 5)
        {
            val Sediento = Sed
            return Sediento + 1
        }else
        {

         //Ir a a taverna
            return taver.taverna(Sed)
        }

    }

    open fun FatigaFun(Fat : Int): Int
    {
        if (Fat < 10)
        {
            val Fatiga = Fat
            return Fatiga + 2
        } else
        {
           //Bob ira a su casa
            return home.Home(Fat)
        }
    }








}