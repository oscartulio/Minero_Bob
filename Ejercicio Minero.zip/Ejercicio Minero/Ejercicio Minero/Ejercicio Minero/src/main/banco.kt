import jdk.nashorn.internal.ir.ReturnNode

open class banco() {

    var oro = 0
    open fun bolsaBanco(GoldPocket: Int): Int{
        // var
        var Anterior = bolsaBanco
        oro = oro + Anterior
        return oro
    }
